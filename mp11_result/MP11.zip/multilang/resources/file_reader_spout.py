# import os
# from os.path import join
from time import sleep

# from streamparse import Spout
import storm


class FileReaderSpout(storm.Spout):

    def initialize(self, conf, context):
        self._conf = conf
        self._context = context
        self._complete = False

        storm.logInfo("Spout instance starting...")

        filePath = conf.get("filePath")
        self._file = open(filePath, "r")
        # End

    def nextTuple(self):
        for cur_sentence in self._file.readlines():
            storm.logInfo("Emit %s now" % cur_sentence)
            storm.emit([cur_sentence])
            
        sleep(1)
        # End


# Start the spout when it's invoked
FileReaderSpout().run()
