import heapq
from collections import Counter

import storm


class TopNFinderBolt(storm.BasicBolt):
    # Initialize this instance
    def initialize(self, conf, context):
        self._conf = conf
        self._context = context

        storm.logInfo("Counter bolt instance starting...")

        self._n_number = conf.get('N')
        # End

        # Hint: Add necessary instance variables and classes if needed
        self._top_n = []       
        self._word_count = {}    

    def process(self, tup):
        self._word_count[tup.values[0]] = tup.values[1]
        counter = Counter(self._wordCount)
        top_n = counter.most_common(self._n_number)     
        
        if self._topN != top_n:
            self._top_n = top_n
            cur_list = [e[0] for e in self._top_n]
            storm.emit([f'top_n', ', '.join(cur_list)])
        # End


# Start the bolt when it's invoked
TopNFinderBolt().run()
